import template from './payrexx-payment-settings-icon.html.twig';

const { Component } = Shopware;

Component.register('payrexx-payment-settings-icon', {
    template
});
