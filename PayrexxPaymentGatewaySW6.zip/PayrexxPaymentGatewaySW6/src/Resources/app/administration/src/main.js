import './module/payrexx-payment';
import './api/payrexx-payment-settings.service';
import './init/svg-icons.init';
